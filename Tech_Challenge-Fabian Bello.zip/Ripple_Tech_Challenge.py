import json
import subprocess
import datetime
import time

Seq_Current = None
Time_Cumm = 0
i = 0
global Ledger_List
global Time_List
global Time_Cumm_List
Time_List = []          #  Ledger validation times list
Time_Cumm_List = []     #  Validation time differences list
Ledger_List = []        #  Ledger sequence numbers list

def getDataFunction():
        global Seq_Current
        global Seq_Counter
        global Time_Cumm
        global Prev_Time
        global i
        #  Sending request to server s1.ripple.com. IP address is 34.201.63.178
        server_response  = subprocess.check_output("rippled --rpc_ip 34.201.63.178:51234 server_info", shell=True)
        #  Converting server response to JSON
        json_data = json.loads(server_response)
        #  Extracting ledger sequence number and validation time
        Ledger_Seq =(json_data['result']['info']['validated_ledger']['seq'])
        Ledger_Time =(json_data['result']['info']['time'])
        #  Adding unique ledger sequence values only
        if Seq_Current != Ledger_Seq:
                        Ledger_List.append(Ledger_Seq)
                        Time_List.append(Ledger_Time)
                        if i  <= 1 :
                                Time_Cumm_List.append(0.00000)  # Inserting first two time difference as 0.0000 because there are no previous values
                        elif i > 1:
                                #   Calculating time difference after starting with the second ledger
                                Time_Cumm =(datetime.datetime.strptime(Time_List[i], "%Y-%b-%d %H:%M:%S.%f UTC") - datetime.datetime.strptime(Time_List[i-1], "%Y-%b-%d %H:%M:%S.%f UTC")).total_seconds()
                                Time_Cumm_List.append(Time_Cumm)
                                #  Printing to file "ledgerdata"
                                print(Ledger_List[i],Time_List[i], Time_Cumm_List[i] , file=open("ledgerdata","a"))
                        i=i+1
        Seq_Current = Ledger_Seq

# Request intervals (1 sec) and total running time (2 mins)
def startTimer():
        end_time = time.time() + 2*60
        start_time=time.time()
        while end_time > time.time():
                time.sleep(1)
                getDataFunction()

startTimer()

def getStatistics():
        Max_Time = max(Time_Cumm_List)
        print("The MAXIMUM validation time was ", Max_Time, " seconds")
        Min_Time = min(Time_Cumm_List[2:(len(Time_Cumm_List))])                                         # Range excludes first two time differences (0.00000) from minimum calculation
        print("The MINIMUM validation time was ", Min_Time, " seconds")
        Average_Time = (sum(Time_Cumm_List[2:(len(Time_Cumm_List))]))/(len(Time_Cumm_List)-2)           # Ranges exclude first two time difference entries from average calculation
        print("The average validation time was ", Average_Time, " seconds")

getStatistics()
